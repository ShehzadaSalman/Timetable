<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <title>Automated TimeTable</title>
    <!-- style goes here  -->
<!-- calling the style files here -->
<?php $__env->startComponent('layouts.components.style'); ?>  
<?php if (isset($__componentOriginal080f2b0d76b3e3f9869357affce0c66c5055d413)): ?>
<?php $component = $__componentOriginal080f2b0d76b3e3f9869357affce0c66c5055d413; ?>
<?php unset($__componentOriginal080f2b0d76b3e3f9869357affce0c66c5055d413); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
</head>
<body>
  <!-- main div starts here-->
<div class="main">



<div class="container-fluid2">
<div class="login-container">
    <div class="login-div">
        <!-- title of the page starts here -->
        <h2 class="text-center"><?php echo e($info[0]->Heading); ?></h2>
        <!-- company logo -->
         <div class="login-logo text-center">

             <img  style=" height:200px;"   src="<?php echo e($info[0]->Path); ?>" alt="know corona">
         </div>
         <!-- form starts here -->
         <form method="POST" action="<?php echo e(route('login')); ?>">
          <?php echo csrf_field(); ?>
        <!-- Email Address starts here -->
          <!-- <input type="email" name="email" id="" class="form-control" placeholder="Enter Username"> -->
          <input id="email" type="email" placeholder="Enter Username" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
              </span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


          <!-- Password starts here -->
          <!-- <input type="password" name="password" id="" class="form-control" placeholder="Enter Password"> -->
          <input id="password" type="password" placeholder="Enter Password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
              </span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>




            <button id = "login-btn" type="submit"  class="form-control btn-primary">Submit</button>

        </form>

     </div>
</div>

</div>
<?php $__env->startComponent('layouts.components.script'); ?>  
<?php if (isset($__componentOriginalb626bfd4d4d1feb10acd31739f77d62824215439)): ?>
<?php $component = $__componentOriginalb626bfd4d4d1feb10acd31739f77d62824215439; ?>
<?php unset($__componentOriginalb626bfd4d4d1feb10acd31739f77d62824215439); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<!-- main div ends here -->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Timetable\resources\views/login.blade.php ENDPATH**/ ?>