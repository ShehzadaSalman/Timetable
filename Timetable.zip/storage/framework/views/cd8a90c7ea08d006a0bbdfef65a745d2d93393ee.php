<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Automated Time Table</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


<!-- styles go here -->

<!-- calling the style files here -->
<?php $__env->startComponent('layouts.components.style'); ?>  
<?php if (isset($__componentOriginal080f2b0d76b3e3f9869357affce0c66c5055d413)): ?>
<?php $component = $__componentOriginal080f2b0d76b3e3f9869357affce0c66c5055d413; ?>
<?php unset($__componentOriginal080f2b0d76b3e3f9869357affce0c66c5055d413); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
</head>
<body>

<div class="wrapper">
 <!-- sidebar goes here -->
 <?php $__env->startComponent('layouts.components.sidebar'); ?>  
<?php $__env->slot('dashboard'); ?>
active
<?php $__env->endSlot(); ?>
<?php if (isset($__componentOriginal4515c28d6be2f8e7ef3bde4257c8a85a33f5571c)): ?>
<?php $component = $__componentOriginal4515c28d6be2f8e7ef3bde4257c8a85a33f5571c; ?>
<?php unset($__componentOriginal4515c28d6be2f8e7ef3bde4257c8a85a33f5571c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">

                </div>
            </div>
        </nav>




<div class="content container-fluid">
<h3>TimeTables for semesters are listed below</h3>
<hr>
<?php if(session()->has('message')): ?>
<div class="alert alert-success">
		<?php echo e(session()->get('message')); ?>

</div>
<?php endif; ?>
<div class="row">


<?php if($timetable->isEmpty()): ?>
<div class="Text-center" style = "padding-top: 30px; padding-bottom: 30px;">
    <p class  ="text-center">There are no Timetables created yet <br>
		<a href ="/slot">Click here</a> to create a timeslot for your Time Table </p>
</div>
<?php endif; ?>

	<?php $__currentLoopData = $timetable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-3">
	<div class="timetable well" style = "padding: 20px;">
		<a href="/timetable/<?php echo e($time->semesterId); ?>"> <p style = "color: #000;">
			Time table for the semester: <b> <?php echo e($time->semesterName); ?></b></p></a>
			<a href="/timetable/<?php echo e($time->semesterId); ?>">
	       <button type = "button" class = "btn btn-primary">View</button>
			</a>
			<a href="/timetableremove/<?php echo e($time->semesterId); ?>">
				<button type = "button" class = "btn btn-secondary">Remove</button>
			</a>

	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>



<?php $__env->startComponent('layouts.components.footer'); ?>  
<?php if (isset($__componentOriginal03dcf620d7ecd8457c1c0aef095767279acab630)): ?>
<?php $component = $__componentOriginal03dcf620d7ecd8457c1c0aef095767279acab630; ?>
<?php unset($__componentOriginal03dcf620d7ecd8457c1c0aef095767279acab630); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<!-- footer goes here -->

    </div>
</div>


</body>

  <!-- scripts goes here -->

  <?php $__env->startComponent('layouts.components.script'); ?>  
<?php if (isset($__componentOriginalb626bfd4d4d1feb10acd31739f77d62824215439)): ?>
<?php $component = $__componentOriginalb626bfd4d4d1feb10acd31739f77d62824215439; ?>
<?php unset($__componentOriginalb626bfd4d4d1feb10acd31739f77d62824215439); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


</html>
<?php /**PATH C:\xampp\htdocs\Timetable\resources\views/dashboard.blade.php ENDPATH**/ ?>